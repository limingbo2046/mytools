﻿using Microsoft.AspNetCore.Mvc;
using MyCompanyName.MyProjectName.Localization;
using Volo.Abp;
using Volo.Abp.AspNetCore.Mvc;

namespace MyCompanyName.MyProjectName
{
    //[Area(ControllerConst.ModuleName)]
    //[RemoteService(Name = ControllerConst.ModuleName)]
    //[Route(ControllerConst.ModuleName)]//该路由会放在url的第一位
    [RemoteService]
    public abstract class MyProjectNameController : AbpController
    {
        protected MyProjectNameController()
        {
            LocalizationResource = typeof(MyProjectNameResource);
        }
    }

    public static class ControllerConst
    {
        public const string ModuleName = "MyProjectName";//模块的缩写，用在版本号的前面，不再使用api前缀
    }
}
